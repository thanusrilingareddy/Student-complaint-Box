@echo off
rem Compile and start the Student Complaint Box (needs JDK 17+)
cd /d "%~dp0"
if not exist out mkdir out
dir /s /b src\*.java > sources.txt
javac -d out @sources.txt
del sources.txt
echo Compiled. Starting server...
java -cp out com.college.complaintbox.Main %*
