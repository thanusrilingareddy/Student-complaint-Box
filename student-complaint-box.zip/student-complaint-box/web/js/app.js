'use strict';

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const state = { user: null, meta: null };

/* ---------- API helper (form-encoded bodies, cookie session) ---------- */
async function api(path, { method = 'GET', data } = {}) {
  const opts = { method, credentials: 'same-origin' };
  if (data) {
    opts.body = new URLSearchParams(data);
    opts.headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
  }
  const res = await fetch(path, opts);
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error || 'Request failed (' + res.status + ')');
  return json;
}

function toast(msg, isError = false) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.toggle('error', isError);
  t.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.remove('show'), 2800);
}

function el(tag, attrs = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v);
  }
  for (const kid of kids) e.append(kid instanceof Node ? kid : document.createTextNode(kid));
  return e; // text is always inserted as text nodes, so user content can never inject HTML
}

const fmt = iso => new Date(iso).toLocaleString(undefined, { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });

/* ---------- Auth ---------- */
$$('.tab').forEach(tab => tab.addEventListener('click', () => {
  $$('.tab').forEach(t => t.classList.toggle('active', t === tab));
  $('#loginForm').hidden = tab.dataset.tab !== 'login';
  $('#registerForm').hidden = tab.dataset.tab !== 'register';
  $('#authError').textContent = '';
}));

$$('[data-demo]').forEach(b => b.addEventListener('click', () => {
  const [u, p] = b.dataset.demo.split(':');
  $('#loginForm [name=username]').value = u;
  $('#loginForm [name=password]').value = p;
}));

async function submitAuth(form, path) {
  const btn = $('button[type=submit]', form);
  btn.disabled = true;
  $('#authError').textContent = '';
  try {
    const { user } = await api(path, { method: 'POST', data: Object.fromEntries(new FormData(form)) });
    await enter(user);
  } catch (e) {
    $('#authError').textContent = e.message;
  } finally {
    btn.disabled = false;
  }
}
$('#loginForm').addEventListener('submit', e => { e.preventDefault(); submitAuth(e.target, '/api/login'); });
$('#registerForm').addEventListener('submit', e => { e.preventDefault(); submitAuth(e.target, '/api/register'); });

$('#logoutBtn').addEventListener('click', async () => {
  await api('/api/logout', { method: 'POST' }).catch(() => {});
  state.user = null;
  $('#topbar').hidden = true;
  $('#dashView').hidden = true;
  $('#authView').hidden = false;
});

/* ---------- Dashboard ---------- */
async function enter(user) {
  state.user = user;
  if (!state.meta) state.meta = await api('/api/meta');
  const admin = user.role === 'ADMIN';

  $('#authView').hidden = true;
  $('#dashView').hidden = false;
  $('#topbar').hidden = false;
  $('#userName').textContent = user.name;
  $('#userRole').textContent = admin ? 'Administrator' : 'Student';
  $('#avatar').textContent = user.name.trim()[0].toUpperCase();
  $('#dashTitle').textContent = admin ? 'All complaints' : 'My complaints';
  $('#dashSub').textContent = admin
    ? 'Review every complaint and update its progress.'
    : 'Track the status of everything you have submitted.';
  $('#submitPanel').hidden = admin;
  $('#exportBtn').hidden = !admin;
  $('.layout').classList.toggle('admin', admin);

  fillSelect($('#categorySelect'), state.meta.categories);
  fillSelect($('#fStatus'), state.meta.statuses, 'All statuses');
  fillSelect($('#fCategory'), state.meta.categories, 'All categories');
  fillSelect($('#fPriority'), state.meta.priorities, 'All priorities');
  await load();
}

function fillSelect(sel, values, placeholder) {
  sel.replaceChildren();
  if (placeholder) sel.append(el('option', { value: '' }, placeholder));
  else sel.append(el('option', { value: '', disabled: '', selected: '' }, 'Choose a category'));
  values.forEach(v => sel.append(el('option', { value: v }, v)));
}

async function load() {
  const params = new URLSearchParams({
    q: $('#searchInput').value, status: $('#fStatus').value,
    category: $('#fCategory').value, priority: $('#fPriority').value
  });
  try {
    const data = await api('/api/complaints?' + params);
    renderStats(data.stats);
    renderList(data.complaints, data.stats.total);
  } catch (e) {
    toast(e.message, true);
  }
}

function renderStats(s) {
  $('#stTotal').textContent = s.total;
  $('#stPending').textContent = s.pending;
  $('#stProgress').textContent = s.inProgress;
  $('#stResolved').textContent = s.resolved;
}

function renderList(items, total) {
  const list = $('#list');
  list.replaceChildren();
  $('#shownInfo').textContent = items.length === total
    ? `${total} complaint${total === 1 ? '' : 's'}`
    : `Showing ${items.length} of ${total} complaints`;

  if (!items.length) {
    list.append(el('div', { class: 'empty' },
      el('div', {}, total ? '🔍' : '📭'),
      total ? 'No complaints match your filters.' : 'No complaints yet. Submit your first one!'));
    return;
  }
  items.forEach((c, i) => {
    const card = card_(c);
    card.style.animationDelay = Math.min(i * 40, 300) + 'ms';
    list.append(card);
  });
}

function card_(c) {
  const admin = state.user.role === 'ADMIN';
  const statusKey = c.status.replace(' ', '');
  const step = ['Pending', 'In Progress', 'Resolved'].indexOf(c.status);

  const card = el('article', { class: `item p-${c.priority.toLowerCase()}` },
    el('div', { class: 'item-head' },
      el('h4', {}, el('small', {}, '#' + c.id), c.title),
      el('div', { class: 'badges' },
        el('span', { class: 'badge cat' }, c.category),
        el('span', { class: 'badge ' + c.priority, title: c.priorityAssumed ? 'No priority was saved on this older record, so it is treated as Medium' : '' },
          c.priority + (c.priorityAssumed ? ' (default)' : '')),
        el('span', { class: 'badge ' + statusKey }, c.status))),
    el('p', { class: 'desc' }, c.description),
    el('div', { class: 'meta' },
      admin && c.student ? el('span', {}, '👤 ' + c.student) : '',
      el('span', {}, '🕒 Submitted ' + fmt(c.createdAt)),
      c.updatedAt !== c.createdAt ? el('span', {}, '🔄 Updated ' + fmt(c.updatedAt)) : ''),
    el('div', { class: 'progress', title: c.status },
      ...[0, 1, 2].map(n => el('i', { class: n <= step ? 'on' : '' }))));

  if (c.adminRemark) card.append(el('div', { class: 'remark' }, el('b', {}, 'Administrator remark'), c.adminRemark));

  if (admin || c.status === 'Pending') {
    const del = el('button', { class: 'btn ghost small danger', type: 'button' }, admin ? 'Delete' : 'Withdraw');
    del.addEventListener('click', async () => {
      if (!confirm(`Delete complaint #${c.id}? This cannot be undone.`)) return;
      try { await api(`/api/complaints/${c.id}/delete`, { method: 'POST' }); toast(`Complaint #${c.id} deleted`); await load(); }
      catch (e) { toast(e.message, true); }
    });
    card.append(el('div', { class: 'del-row' }, del));
  }

  if (admin) {
    const select = el('select', {});
    state.meta.statuses.forEach(s => select.append(el('option', { value: s }, s)));
    select.value = c.status;
    const remark = el('input', { placeholder: 'Remark for the student (optional)', maxlength: '500' });
    remark.value = c.adminRemark || '';
    const btn = el('button', { class: 'btn primary small', type: 'button' }, 'Update');
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      try {
        await api(`/api/complaints/${c.id}/status`, { method: 'POST', data: { status: select.value, remark: remark.value } });
        toast(`Complaint #${c.id} marked ${select.value}`);
        await load();
      } catch (e) { toast(e.message, true); btn.disabled = false; }
    });
    card.append(el('div', { class: 'admin-box' }, select, remark, btn));
  }
  return card;
}

/* ---------- Submit complaint ---------- */
$('#complaintForm').addEventListener('submit', async e => {
  e.preventDefault();
  const form = e.target, btn = $('button[type=submit]', form);
  $('#submitError').textContent = '';
  btn.disabled = true;
  try {
    await api('/api/complaints', { method: 'POST', data: Object.fromEntries(new FormData(form)) });
    form.reset();
    toast('Complaint submitted successfully ✔');
    await load();
  } catch (err) {
    $('#submitError').textContent = err.message;
  } finally {
    btn.disabled = false;
  }
});

/* ---------- Search / filter ---------- */
let debounce;
$('#searchInput').addEventListener('input', () => { clearTimeout(debounce); debounce = setTimeout(load, 250); });
['#fStatus', '#fCategory', '#fPriority'].forEach(s => $(s).addEventListener('change', load));

/* ---------- Boot: restore session if the cookie is still valid ---------- */
api('/api/me').then(({ user }) => enter(user)).catch(() => { /* not logged in */ });
