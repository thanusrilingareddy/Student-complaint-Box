# Student Complaint Box (Java)

A college complaint portal where students submit complaints and follow the action taken by administrators.
Starts with **zero complaints** (accounts only). Students can also withdraw their own Pending complaints; admins can delete any and export CSV.
Backend: **pure Java 17+** (JDK `com.sun.net.httpserver`, no frameworks or external libraries).
Frontend: HTML + CSS (gradients, glassmorphism) + vanilla JavaScript, served by the Java server.

## Run it
```bash
./run.sh          # Linux / macOS   (Windows: run.bat)
# open http://localhost:8080        (custom port: ./run.sh 9000)
```
Only a JDK is needed. First start creates demo data in `data/`.

| Role | Username | Password |
|---|---|---|
| Admin | admin | admin123 |
| Student | ravi | student123 |
| Student | ananya | student123 |

New students can also sign up from the login page.

## Requirement mapping
| # | Requirement | Where |
|---|---|---|
| 1 | Submit complaint (title, description, category) | `ApiHandler.submit`, form in `web/index.html` |
| 2 | Students view only their own complaints | `ApiHandler.list` filters by `studentId` |
| 3 | Admin sets Pending / In Progress / Resolved | `ApiHandler.updateStatus` (403 for students) |
| 4 | Priority Low/Medium/High required for new complaints | `Priority.parseRequired` rejects blank/invalid with HTTP 400 |
| 5 | Old records without priority = Medium | `Complaint.effectivePriority()`; UI shows "Medium (default)" |
| Optional | Search/filter + pending/in-progress/resolved counts | `/api/complaints?q=&status=&category=&priority=`, stat cards |

## Structure
```
student-complaint-box/
├── run.sh / run.bat / pom.xml
├── data/                      users.tsv, complaints.tsv (created on first run)
├── web/                       index.html, css/style.css, js/app.js
└── src/main/java/com/college/complaintbox/
    ├── Main.java              server bootstrap
    ├── model/                 Complaint, User, Priority, Status, Category, Role
    ├── store/                 UserStore, ComplaintStore (file persistence), DemoData
    ├── web/                   ApiHandler, StaticHandler, Sessions, Json, HttpException
    └── util/                  PasswordHasher (salted SHA-256), Tsv
```

## API
`POST /api/login | /api/register | /api/logout`, `GET /api/me | /api/meta`,
`GET|POST /api/complaints`, `POST /api/complaints/{id}/status`.

## Security notes
Salted password hashes, HttpOnly SameSite cookies, role checks on the server, path-traversal guard on static files, and all user text rendered as text nodes (no XSS).
