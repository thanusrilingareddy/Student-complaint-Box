package com.college.complaintbox.web;

import java.util.Collection;

/** Minimal JSON writer (output only; request bodies use form encoding). */
public final class Json {
    private Json() {}

    /** Pre-rendered JSON fragment. */
    public record Raw(String json) {}

    public static Raw raw(String json) { return new Raw(json); }

    public static String quote(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder(s.length() + 2).append('"');
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
                }
            }
        }
        return sb.append('"').toString();
    }

    public static String value(Object v) {
        if (v == null) return "null";
        if (v instanceof Raw r) return r.json();
        if (v instanceof Number || v instanceof Boolean) return v.toString();
        return quote(v.toString());
    }

    /** obj("a", 1, "b", "x") -> {"a":1,"b":"x"} */
    public static String obj(Object... kv) {
        StringBuilder sb = new StringBuilder("{");
        for (int i = 0; i < kv.length; i += 2) {
            if (i > 0) sb.append(',');
            sb.append(quote((String) kv[i])).append(':').append(value(kv[i + 1]));
        }
        return sb.append('}').toString();
    }

    public static String arr(Collection<?> items) {
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (Object o : items) {
            if (!first) sb.append(',');
            first = false;
            sb.append(value(o));
        }
        return sb.append(']').toString();
    }
}
