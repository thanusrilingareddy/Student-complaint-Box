package com.college.complaintbox.web;

import com.college.complaintbox.model.User;

import java.security.SecureRandom;
import java.util.HexFormat;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/** In-memory cookie sessions: random token -> user id. */
public final class Sessions {
    public static final String COOKIE = "SID";
    private final Map<String, Integer> tokens = new ConcurrentHashMap<>();
    private final SecureRandom rng = new SecureRandom();

    public String start(User u) {
        byte[] b = new byte[24];
        rng.nextBytes(b);
        String token = HexFormat.of().formatHex(b);
        tokens.put(token, u.id());
        return token;
    }

    public Optional<Integer> userId(String token) {
        return token == null ? Optional.empty() : Optional.ofNullable(tokens.get(token));
    }

    public void end(String token) {
        if (token != null) tokens.remove(token);
    }
}
