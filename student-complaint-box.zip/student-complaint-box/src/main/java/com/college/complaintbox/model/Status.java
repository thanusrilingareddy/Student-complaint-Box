package com.college.complaintbox.model;

/** Progress of a complaint, updated only by administrators. */
public enum Status {
    PENDING("Pending"), IN_PROGRESS("In Progress"), RESOLVED("Resolved");

    public final String label;

    Status(String label) { this.label = label; }

    public static Status parse(String s) {
        if (s == null || s.isBlank()) throw new IllegalArgumentException("Status is required.");
        String t = s.trim();
        for (Status v : values()) {
            if (v.label.equalsIgnoreCase(t) || v.name().equalsIgnoreCase(t)) return v;
        }
        throw new IllegalArgumentException("Invalid status '" + s + "'. Use Pending, In Progress or Resolved.");
    }
}
