package com.college.complaintbox;

import com.college.complaintbox.store.ComplaintStore;
import com.college.complaintbox.store.DemoData;
import com.college.complaintbox.store.UserStore;
import com.college.complaintbox.web.ApiHandler;
import com.college.complaintbox.web.Sessions;
import com.college.complaintbox.web.StaticHandler;
import com.sun.net.httpserver.HttpServer;

import java.net.InetSocketAddress;
import java.nio.file.Path;
import java.util.concurrent.Executors;

/**
 * Student Complaint Box - entry point.
 * Usage: java -cp out com.college.complaintbox.Main [port]
 * Env/props: PORT, -Ddata.dir=data, -Dweb.dir=web
 */
public final class Main {
    public static void main(String[] args) throws Exception {
        int port = args.length > 0 ? Integer.parseInt(args[0])
                : Integer.parseInt(System.getenv().getOrDefault("PORT", "8080"));
        Path dataDir = Path.of(System.getProperty("data.dir", "data"));
        Path webDir = Path.of(System.getProperty("web.dir", "web"));

        UserStore users = new UserStore(dataDir.resolve("users.tsv"));
        ComplaintStore complaints = new ComplaintStore(dataDir.resolve("complaints.tsv"));
        if (users.isEmpty()) {
            DemoData.seed(users, complaints);
            System.out.println("First run: demo data created (admin/admin123, ravi/student123, ananya/student123).");
        }

        ApiHandler api = new ApiHandler(users, complaints, new Sessions());
        StaticHandler statics = new StaticHandler(webDir);

        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/", ex -> {
            try {
                if (ex.getRequestURI().getPath().startsWith("/api/")) api.handle(ex);
                else statics.handle(ex);
            } catch (Exception e) {
                e.printStackTrace();
                ex.close();
            }
        });
        server.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
        server.start();
        System.out.println("Student Complaint Box running at http://localhost:" + port);
    }
}
