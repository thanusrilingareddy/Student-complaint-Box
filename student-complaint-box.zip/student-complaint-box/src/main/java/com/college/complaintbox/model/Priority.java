package com.college.complaintbox.model;

/** Complaint priority. Required for every NEW complaint; legacy records may have none. */
public enum Priority {
    LOW("Low"), MEDIUM("Medium"), HIGH("High");

    public final String label;

    Priority(String label) { this.label = label; }

    /** Strict parse used for new submissions: blank or unknown values are rejected. */
    public static Priority parseRequired(String s) {
        if (s == null || s.isBlank()) {
            throw new IllegalArgumentException("Priority is required (Low, Medium or High).");
        }
        for (Priority p : values()) {
            if (p.label.equalsIgnoreCase(s.trim()) || p.name().equalsIgnoreCase(s.trim())) return p;
        }
        throw new IllegalArgumentException("Invalid priority '" + s + "'. Use Low, Medium or High.");
    }

    /** Lenient parse used when reading stored data: missing priority means null (treated as Medium). */
    public static Priority parseStored(String s) {
        if (s == null || s.isBlank()) return null;
        try { return parseRequired(s); } catch (IllegalArgumentException e) { return null; }
    }
}
