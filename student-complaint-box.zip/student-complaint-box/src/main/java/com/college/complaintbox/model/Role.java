package com.college.complaintbox.model;

public enum Role { STUDENT, ADMIN }
