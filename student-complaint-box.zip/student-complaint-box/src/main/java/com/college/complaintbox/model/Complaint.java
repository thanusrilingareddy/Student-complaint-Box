package com.college.complaintbox.model;

import java.time.Instant;

/**
 * An immutable complaint. {@code priority} is nullable ONLY for older records saved before
 * priority existed; those are treated as Medium via {@link #effectivePriority()}.
 */
public record Complaint(long id, int studentId, String title, String description,
                        Category category, Priority priority, Status status,
                        Instant createdAt, Instant updatedAt, String adminRemark) {

    /** Requirement 5: complaints with no priority saved are treated as Medium. */
    public Priority effectivePriority() {
        return priority == null ? Priority.MEDIUM : priority;
    }

    public boolean priorityAssumed() { return priority == null; }

    public Complaint withStatus(Status newStatus, String remark, Instant when) {
        return new Complaint(id, studentId, title, description, category, priority,
                newStatus, createdAt, when, remark == null ? "" : remark);
    }
}
