package com.college.complaintbox.model;

public enum Category {
    ACADEMIC("Academic"), HOSTEL("Hostel"), LIBRARY("Library"), CANTEEN("Canteen"),
    TRANSPORT("Transport"), INFRASTRUCTURE("Infrastructure"), FACULTY("Faculty"), OTHER("Other");

    public final String label;

    Category(String label) { this.label = label; }

    public static Category parse(String s) {
        if (s == null || s.isBlank()) throw new IllegalArgumentException("Category is required.");
        String t = s.trim();
        for (Category c : values()) {
            if (c.label.equalsIgnoreCase(t) || c.name().equalsIgnoreCase(t)) return c;
        }
        throw new IllegalArgumentException("Invalid category '" + s + "'.");
    }
}
