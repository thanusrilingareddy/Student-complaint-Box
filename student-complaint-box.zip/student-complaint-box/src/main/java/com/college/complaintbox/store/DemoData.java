package com.college.complaintbox.store;

import com.college.complaintbox.model.*;


/** First-run demo data: one admin and two students, with zero complaints. */
public final class DemoData {
    private DemoData() {}

    public static void seed(UserStore users, ComplaintStore complaints) {
        users.create("admin", "College Administrator", "admin123", Role.ADMIN);
        users.create("ravi", "Ravi Kumar", "student123", Role.STUDENT);
        users.create("ananya", "Ananya Reddy", "student123", Role.STUDENT);

        // No complaints are seeded: the complaint list starts at zero.
    }
}
