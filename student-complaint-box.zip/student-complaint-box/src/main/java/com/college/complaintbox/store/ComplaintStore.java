package com.college.complaintbox.store;

import com.college.complaintbox.model.*;
import com.college.complaintbox.util.Tsv;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;

/**
 * File-backed complaint repository (data/complaints.tsv). Thread-safe.
 * The priority column may be blank for older records; those load with priority == null
 * and are treated as Medium by {@link Complaint#effectivePriority()}.
 */
public final class ComplaintStore {
    private final Path file;
    private final List<Complaint> items = new ArrayList<>();
    private long seq = 0;

    public ComplaintStore(Path file) throws IOException {
        this.file = file;
        if (Files.exists(file)) load();
    }

    private void load() throws IOException {
        for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
            if (line.isBlank()) continue;
            List<String> f = Tsv.split(line);
            // id, studentId, title, description, category, priority(may be blank), status, created, updated, remark
            Complaint c = new Complaint(
                    Long.parseLong(f.get(0)), Integer.parseInt(f.get(1)), f.get(2), f.get(3),
                    Category.parse(f.get(4)), Priority.parseStored(f.get(5)),
                    Status.parse(f.get(6)), Instant.parse(f.get(7)), Instant.parse(f.get(8)),
                    f.size() > 9 ? f.get(9) : "");
            items.add(c);
            seq = Math.max(seq, c.id());
        }
    }

    private void save() {
        try {
            List<String> lines = new ArrayList<>();
            for (Complaint c : items) {
                lines.add(Tsv.join(String.valueOf(c.id()), String.valueOf(c.studentId()), c.title(),
                        c.description(), c.category().name(),
                        c.priority() == null ? "" : c.priority().name(),
                        c.status().name(), c.createdAt().toString(), c.updatedAt().toString(),
                        c.adminRemark()));
            }
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.createDirectories(file.toAbsolutePath().getParent());
            Files.write(tmp, lines, StandardCharsets.UTF_8);
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            throw new IllegalStateException("Could not save complaints", e);
        }
    }

    public synchronized boolean isEmpty() { return items.isEmpty(); }

    /** Inserts a complaint. {@code priority} is only null for seeded legacy data. */
    public synchronized Complaint add(int studentId, String title, String description, Category category,
                                      Priority priority, Status status, Instant createdAt) {
        Complaint c = new Complaint(++seq, studentId, title, description, category, priority, status,
                createdAt, createdAt, "");
        items.add(c);
        save();
        return c;
    }

    public synchronized Optional<Complaint> update(long id, Status status, String remark) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).id() == id) {
                Complaint updated = items.get(i).withStatus(status, remark, Instant.now());
                items.set(i, updated);
                save();
                return Optional.of(updated);
            }
        }
        return Optional.empty();
    }

    public synchronized Optional<Complaint> find(long id) {
        return items.stream().filter(c -> c.id() == id).findFirst();
    }

    public synchronized boolean remove(long id) {
        boolean gone = items.removeIf(c -> c.id() == id);
        if (gone) save();
        return gone;
    }

    public synchronized List<Complaint> all() { return List.copyOf(items); }
}
