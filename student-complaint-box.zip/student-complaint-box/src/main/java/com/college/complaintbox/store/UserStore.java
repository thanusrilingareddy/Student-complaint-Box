package com.college.complaintbox.store;

import com.college.complaintbox.model.Role;
import com.college.complaintbox.model.User;
import com.college.complaintbox.util.PasswordHasher;
import com.college.complaintbox.util.Tsv;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** File-backed user repository (data/users.tsv). Thread-safe. */
public final class UserStore {
    private final Path file;
    private final List<User> users = new ArrayList<>();
    private int seq = 0;

    public UserStore(Path file) throws IOException {
        this.file = file;
        if (Files.exists(file)) load();
    }

    private void load() throws IOException {
        for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
            if (line.isBlank()) continue;
            List<String> f = Tsv.split(line);
            User u = new User(Integer.parseInt(f.get(0)), f.get(1), f.get(2),
                    Role.valueOf(f.get(3)), f.get(4), f.get(5));
            users.add(u);
            seq = Math.max(seq, u.id());
        }
    }

    private void save() {
        try {
            List<String> lines = new ArrayList<>();
            for (User u : users) {
                lines.add(Tsv.join(String.valueOf(u.id()), u.username(), u.name(),
                        u.role().name(), u.salt(), u.hash()));
            }
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.createDirectories(file.toAbsolutePath().getParent());
            Files.write(tmp, lines, StandardCharsets.UTF_8);
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            throw new IllegalStateException("Could not save users", e);
        }
    }

    public synchronized boolean isEmpty() { return users.isEmpty(); }

    public synchronized User create(String username, String name, String password, Role role) {
        String uname = username.trim().toLowerCase(Locale.ROOT);
        if (findByUsername(uname).isPresent()) {
            throw new IllegalArgumentException("That username is already taken.");
        }
        String salt = PasswordHasher.newSalt();
        User u = new User(++seq, uname, name.trim(), role, salt, PasswordHasher.hash(salt, password));
        users.add(u);
        save();
        return u;
    }

    public synchronized Optional<User> findByUsername(String username) {
        String u = username == null ? "" : username.trim().toLowerCase(Locale.ROOT);
        return users.stream().filter(x -> x.username().equals(u)).findFirst();
    }

    public synchronized Optional<User> findById(int id) {
        return users.stream().filter(x -> x.id() == id).findFirst();
    }

    /** Returns the user when credentials are valid. */
    public Optional<User> authenticate(String username, String password) {
        return findByUsername(username)
                .filter(u -> PasswordHasher.matches(u.salt(), u.hash(), password == null ? "" : password));
    }
}
