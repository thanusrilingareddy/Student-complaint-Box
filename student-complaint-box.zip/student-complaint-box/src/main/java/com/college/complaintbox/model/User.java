package com.college.complaintbox.model;

public record User(int id, String username, String name, Role role, String salt, String hash) {
    public boolean isAdmin() { return role == Role.ADMIN; }
}
