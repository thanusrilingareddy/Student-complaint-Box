package com.college.complaintbox.web;

import com.college.complaintbox.model.*;
import com.college.complaintbox.store.ComplaintStore;
import com.college.complaintbox.store.UserStore;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/** REST-style JSON API under /api. */
public final class ApiHandler {
    private static final Pattern STATUS_PATH = Pattern.compile("^/api/complaints/(\\d+)/status$");
    private static final Pattern DELETE_PATH = Pattern.compile("^/api/complaints/(\\d+)/delete$");
    private static final Pattern USERNAME = Pattern.compile("^[a-z0-9_]{3,20}$");

    private final UserStore users;
    private final ComplaintStore complaints;
    private final Sessions sessions;

    public ApiHandler(UserStore users, ComplaintStore complaints, Sessions sessions) {
        this.users = users;
        this.complaints = complaints;
        this.sessions = sessions;
    }

    /** Handles one request and writes the JSON response. */
    public void handle(HttpExchange ex) throws IOException {
        try {
            String body = route(ex);
            if (body != null) send(ex, 200, body);
        } catch (HttpException e) {
            send(ex, e.status, Json.obj("error", e.getMessage()));
        } catch (IllegalArgumentException e) {
            send(ex, 400, Json.obj("error", e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
            send(ex, 500, Json.obj("error", "Something went wrong on the server."));
        }
    }

    // ------------------------------------------------------------------ routing

    private String route(HttpExchange ex) throws IOException {
        String method = ex.getRequestMethod();
        String path = ex.getRequestURI().getPath();

        if (path.equals("/api/meta") && method.equals("GET")) return meta();
        if (path.equals("/api/login") && method.equals("POST")) return login(ex);
        if (path.equals("/api/register") && method.equals("POST")) return register(ex);
        if (path.equals("/api/logout") && method.equals("POST")) return logout(ex);
        if (path.equals("/api/me") && method.equals("GET")) return me(ex);
        if (path.equals("/api/complaints") && method.equals("GET")) return list(ex);
        if (path.equals("/api/complaints") && method.equals("POST")) return submit(ex);

        Matcher m = STATUS_PATH.matcher(path);
        if (m.matches() && method.equals("POST")) return updateStatus(ex, Long.parseLong(m.group(1)));

        Matcher d = DELETE_PATH.matcher(path);
        if (d.matches() && method.equals("POST")) return delete(ex, Long.parseLong(d.group(1)));
        if (path.equals("/api/export") && method.equals("GET")) { exportCsv(ex); return null; }

        throw new HttpException(404, "Unknown API endpoint.");
    }

    // ------------------------------------------------------------------ endpoints

    private String meta() {
        return Json.obj(
                "categories", Json.raw(Json.arr(Arrays.stream(Category.values()).map(c -> c.label).toList())),
                "priorities", Json.raw(Json.arr(Arrays.stream(Priority.values()).map(p -> p.label).toList())),
                "statuses", Json.raw(Json.arr(Arrays.stream(Status.values()).map(s -> s.label).toList())));
    }

    private String login(HttpExchange ex) throws IOException {
        Map<String, String> f = form(ex);
        User u = users.authenticate(f.get("username"), f.get("password"))
                .orElseThrow(() -> new HttpException(401, "Wrong username or password."));
        startSession(ex, u);
        return Json.obj("user", Json.raw(userJson(u)));
    }

    private String register(HttpExchange ex) throws IOException {
        Map<String, String> f = form(ex);
        String name = trim(f.get("name"));
        String username = trim(f.get("username")).toLowerCase(Locale.ROOT);
        String password = f.getOrDefault("password", "");
        if (name.length() < 2 || name.length() > 60) throw new IllegalArgumentException("Enter your full name (2-60 characters).");
        if (!USERNAME.matcher(username).matches()) throw new IllegalArgumentException("Username must be 3-20 characters: letters, digits or underscore.");
        if (password.length() < 6) throw new IllegalArgumentException("Password must be at least 6 characters.");
        User u = users.create(username, name, password, Role.STUDENT); // public sign-up is always a student
        startSession(ex, u);
        return Json.obj("user", Json.raw(userJson(u)));
    }

    private String logout(HttpExchange ex) {
        sessions.end(cookie(ex));
        ex.getResponseHeaders().add("Set-Cookie", Sessions.COOKIE + "=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax");
        return Json.obj("ok", true);
    }

    private String me(HttpExchange ex) {
        return Json.obj("user", Json.raw(userJson(requireUser(ex))));
    }

    /** Students get only their own complaints; admins get all. Supports q/status/category/priority filters. */
    private String list(HttpExchange ex) {
        User me = requireUser(ex);
        Map<String, String> q = query(ex);

        List<Complaint> visible = complaints.all().stream()
                .filter(c -> me.isAdmin() || c.studentId() == me.id())
                .sorted(Comparator.comparing(Complaint::createdAt).reversed())
                .toList();

        // Counts are for everything the user may see, independent of the filters.
        long pending = visible.stream().filter(c -> c.status() == Status.PENDING).count();
        long progress = visible.stream().filter(c -> c.status() == Status.IN_PROGRESS).count();
        long resolved = visible.stream().filter(c -> c.status() == Status.RESOLVED).count();

        String text = q.getOrDefault("q", "").trim().toLowerCase(Locale.ROOT);
        String status = q.getOrDefault("status", "");
        String category = q.getOrDefault("category", "");
        String priority = q.getOrDefault("priority", "");

        List<Complaint> filtered = visible.stream()
                .filter(c -> status.isBlank() || c.status() == Status.parse(status))
                .filter(c -> category.isBlank() || c.category() == Category.parse(category))
                .filter(c -> priority.isBlank() || c.effectivePriority() == Priority.parseRequired(priority))
                .filter(c -> text.isEmpty() || matches(c, text))
                .toList();

        List<String> rows = filtered.stream().map(c -> complaintJson(c, me.isAdmin())).collect(Collectors.toList());
        return Json.obj(
                "complaints", Json.raw(Json.arr(rows.stream().map(Json::raw).toList())),
                "stats", Json.raw(Json.obj("total", visible.size(), "pending", pending,
                        "inProgress", progress, "resolved", resolved)),
                "shown", filtered.size());
    }

    private boolean matches(Complaint c, String text) {
        String student = users.findById(c.studentId()).map(User::name).orElse("").toLowerCase(Locale.ROOT);
        return c.title().toLowerCase(Locale.ROOT).contains(text)
                || c.description().toLowerCase(Locale.ROOT).contains(text)
                || c.category().label.toLowerCase(Locale.ROOT).contains(text)
                || student.contains(text)
                || ("#" + c.id()).equals(text) || String.valueOf(c.id()).equals(text);
    }

    /** Requirement 1 + 4: title, description, category and a REQUIRED priority. */
    private String submit(HttpExchange ex) throws IOException {
        User me = requireUser(ex);
        if (me.isAdmin()) throw new HttpException(403, "Only students can submit complaints.");
        Map<String, String> f = form(ex);

        String title = trim(f.get("title"));
        String description = trim(f.get("description"));
        if (title.length() < 5 || title.length() > 100) throw new IllegalArgumentException("Title must be 5-100 characters.");
        if (description.length() < 15 || description.length() > 2000) throw new IllegalArgumentException("Description must be 15-2000 characters.");
        Category category = Category.parse(f.get("category"));
        Priority priority = Priority.parseRequired(f.get("priority")); // throws when missing

        Complaint c = complaints.add(me.id(), title, description, category, priority, Status.PENDING, Instant.now());
        return Json.obj("complaint", Json.raw(complaintJson(c, false)));
    }

    /** Requirement 3: only administrators move a complaint through Pending / In Progress / Resolved. */
    private String updateStatus(HttpExchange ex, long id) throws IOException {
        User me = requireUser(ex);
        if (!me.isAdmin()) throw new HttpException(403, "Only administrators can update complaint status.");
        Map<String, String> f = form(ex);
        Status status = Status.parse(f.get("status"));
        String remark = trim(f.get("remark"));
        if (remark.length() > 500) throw new IllegalArgumentException("Remark is too long (max 500 characters).");
        Complaint c = complaints.update(id, status, remark)
                .orElseThrow(() -> new HttpException(404, "Complaint #" + id + " not found."));
        return Json.obj("complaint", Json.raw(complaintJson(c, true)));
    }

    /** Admins may delete any complaint; students only their own while it is still Pending. */
    private String delete(HttpExchange ex, long id) {
        User me = requireUser(ex);
        Complaint c = complaints.find(id).orElseThrow(() -> new HttpException(404, "Complaint #" + id + " not found."));
        if (!me.isAdmin()) {
            if (c.studentId() != me.id()) throw new HttpException(403, "You can only delete your own complaints.");
            if (c.status() != Status.PENDING) throw new HttpException(403, "Only Pending complaints can be withdrawn.");
        }
        complaints.remove(id);
        return Json.obj("ok", true);
    }

    /** Admin-only CSV download of all complaints. */
    private void exportCsv(HttpExchange ex) throws IOException {
        User me = requireUser(ex);
        if (!me.isAdmin()) throw new HttpException(403, "Only administrators can export.");
        StringBuilder sb = new StringBuilder("ID,Student,Title,Category,Priority,Status,Submitted,Updated,Remark\n");
        for (Complaint c : complaints.all()) {
            String student = users.findById(c.studentId()).map(User::name).orElse("");
            sb.append(c.id()).append(',').append(csv(student)).append(',').append(csv(c.title())).append(',')
              .append(csv(c.category().label)).append(',').append(csv(c.effectivePriority().label)).append(',')
              .append(csv(c.status().label)).append(',').append(c.createdAt()).append(',').append(c.updatedAt())
              .append(',').append(csv(c.adminRemark())).append('\n');
        }
        byte[] out = sb.toString().getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "text/csv; charset=utf-8");
        ex.getResponseHeaders().set("Content-Disposition", "attachment; filename=\"complaints.csv\"");
        ex.sendResponseHeaders(200, out.length);
        ex.getResponseBody().write(out);
        ex.close();
    }

    private static String csv(String s) {
        String v = s == null ? "" : s;
        if (!v.isEmpty() && "=+-@".indexOf(v.charAt(0)) >= 0) v = "'" + v; // block spreadsheet formula injection
        return "\"" + v.replace("\"", "\"\"") + "\"";
    }

    // ------------------------------------------------------------------ JSON views

    private String userJson(User u) {
        return Json.obj("id", u.id(), "username", u.username(), "name", u.name(), "role", u.role().name());
    }

    private String complaintJson(Complaint c, boolean includeStudent) {
        String student = users.findById(c.studentId()).map(User::name).orElse("Unknown student");
        return Json.obj(
                "id", c.id(),
                "title", c.title(),
                "description", c.description(),
                "category", c.category().label,
                "priority", c.effectivePriority().label,
                "priorityAssumed", c.priorityAssumed(),
                "status", c.status().label,
                "createdAt", c.createdAt().toString(),
                "updatedAt", c.updatedAt().toString(),
                "adminRemark", c.adminRemark(),
                "student", includeStudent ? student : null);
    }

    // ------------------------------------------------------------------ helpers

    private User requireUser(HttpExchange ex) {
        return sessions.userId(cookie(ex)).flatMap(users::findById)
                .orElseThrow(() -> new HttpException(401, "Please log in first."));
    }

    private void startSession(HttpExchange ex, User u) {
        String token = sessions.start(u);
        ex.getResponseHeaders().add("Set-Cookie",
                Sessions.COOKIE + "=" + token + "; Path=/; HttpOnly; SameSite=Lax; Max-Age=86400");
    }

    private String cookie(HttpExchange ex) {
        String header = ex.getRequestHeaders().getFirst("Cookie");
        if (header == null) return null;
        for (String part : header.split(";")) {
            String p = part.trim();
            if (p.startsWith(Sessions.COOKIE + "=")) return p.substring(Sessions.COOKIE.length() + 1);
        }
        return null;
    }

    private static String trim(String s) { return s == null ? "" : s.trim(); }

    private Map<String, String> form(HttpExchange ex) throws IOException {
        byte[] bytes = ex.getRequestBody().readNBytes(64 * 1024);
        return parseForm(new String(bytes, StandardCharsets.UTF_8));
    }

    private Map<String, String> query(HttpExchange ex) {
        String raw = ex.getRequestURI().getRawQuery();
        return raw == null ? Map.of() : parseForm(raw);
    }

    private static Map<String, String> parseForm(String s) {
        Map<String, String> map = new HashMap<>();
        if (s == null || s.isBlank()) return map;
        for (String pair : s.split("&")) {
            int i = pair.indexOf('=');
            String k = URLDecoder.decode(i < 0 ? pair : pair.substring(0, i), StandardCharsets.UTF_8);
            String v = i < 0 ? "" : URLDecoder.decode(pair.substring(i + 1), StandardCharsets.UTF_8);
            map.put(k, v);
        }
        return map;
    }

    private static void send(HttpExchange ex, int status, String json) throws IOException {
        byte[] out = json.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.getResponseHeaders().set("Cache-Control", "no-store");
        ex.sendResponseHeaders(status, out.length);
        ex.getResponseBody().write(out);
        ex.close();
    }
}
