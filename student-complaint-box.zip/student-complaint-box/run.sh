#!/usr/bin/env bash
# Compile and start the Student Complaint Box. Needs only a JDK (17+).
set -e
cd "$(dirname "$0")"
mkdir -p out
javac -d out $(find src -name '*.java')
echo "Compiled. Starting server..."
exec java -cp out com.college.complaintbox.Main "$@"
